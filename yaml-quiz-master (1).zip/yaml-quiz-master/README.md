# YAML Practice Interface

This is a quiz App used to help a beginner gain practice on YAML basics

